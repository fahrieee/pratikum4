<div class="col-md-12">
    <h3>
        Daftar Pasien
    </h3>
    <table class="table">
        <thead>
            <tr>
                <th>#</th><th>Tanggal</th><th>Kode</th><th>Nama</th><th>Gender</th><th>Berat</th><th>Tinggi</th><th>BMI</th><th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $nomor=1;
                foreach ($list_bmipasien as $pasien)
                {
            
                
                    /* <td><?=$nomor?></td>
                    <td><?=$pasien->kode?></td>
                    <td><?=$pasien->nama?></td>
                    <td><?=$pasien->gender?></td> */
                
                        echo '<tr><td>'.$nomor.'</td>';
                        echo '<td>'.$pasien->tanggal.'</td>';
                        echo '<td>'.$pasien->pasien->kode.'</td>';
                        echo '<td>'.$pasien->pasien->nama.'</td>';
                        echo '<td>'.$pasien->pasien->gender.'</td>';
                        echo '<td>'.$pasien->bmi->berat.'</td>';
                        echo '<td>'.$pasien->bmi->tinggi.'</td>';
                        echo '<td>'.$pasien->bmi->nilaiBMI().'</td>';
                        echo '<td>'.$pasien->bmi->statusBMI().'</td>';
                        echo '</tr>';
                
            
                $nomor++;
            
                }
            ?>
        </tbody>
    </table>
</div>