<?php
class Bmi_pasien extends CI_Model {

    public $id;
    public $tanggal;
    public $pasien;
    public $bmi;
    


}